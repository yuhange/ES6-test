{
	let a = 1;
	var b = 2;
}
alert(b);
alert(a);